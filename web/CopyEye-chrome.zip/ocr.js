/**
 * The recogniser. Everything it needs is a file inside this extension — the worker, the wasm
 * core and both language models. There is no fetch to anywhere in this file, which is why the
 * extension keeps working with the network off, and why nothing you scan can leave the machine.
 */

const LANGS = 'eng+hin';

let workerPromise = null;

function url(p) {
  return chrome.runtime.getURL(p);
}

async function getWorker() {
  if (workerPromise) return workerPromise;
  workerPromise = Tesseract.createWorker(LANGS, 1, {
    workerPath: url('vendor/worker.min.js'),
    // A directory: Tesseract picks the SIMD build when the CPU has it and the plain one when
    // it does not, so both are shipped.
    corePath: url('vendor/'),
    // Tesseract appends `<lang>.traineddata.gz` to this.
    langPath: url('lang'),
    // The models are already on disk; without this it tries to write them to IndexedDB and
    // re-reads them from a cache that can silently go stale.
    cacheMethod: 'none',
    gzip: true,
  });
  return workerPromise;
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type !== 'copyeye:offscreen-ocr') return;
  (async () => {
    try {
      const worker = await getWorker();
      const { data } = await worker.recognize(msg.dataUrl);
      const text = (data?.text || '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
      reply({ ok: true, text });
    } catch (e) {
      reply({ ok: false, message: String(e?.message || e) });
    }
  })();
  return true;
});
