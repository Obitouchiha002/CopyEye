/**
 * Everything the user actually sees: the drag-a-box picker, the video-frame grab, and the panel
 * that shows what was read.
 *
 * The panel lives in a shadow root. A content script paints on top of somebody else's page, and
 * without that isolation the host page's CSS reaches in and wrecks the layout on roughly every
 * third site.
 */

const PANEL_ID = 'copyeye-root';
let host = null;
let shadow = null;
let lastText = '';

/* ---------- shell ---------- */

function mount() {
  if (host && document.documentElement.contains(host)) return;
  host = document.createElement('div');
  host.id = PANEL_ID;
  host.style.cssText = 'all:initial;position:fixed;inset:auto 16px 16px auto;z-index:2147483647';
  shadow = host.attachShadow({ mode: 'open' });
  const style = document.createElement('style');
  style.textContent = PANEL_CSS;
  shadow.append(style);
  document.documentElement.append(host);
}

function render(html) {
  mount();
  const old = shadow.querySelector('.panel');
  if (old) old.remove();
  const wrap = document.createElement('div');
  wrap.className = 'panel';
  wrap.innerHTML = html;
  shadow.append(wrap);
  return wrap;
}

function close() {
  host?.remove();
  host = null;
  shadow = null;
}

const eyeSvg = `<svg class="eye" viewBox="0 0 40 40" aria-hidden="true">
  <circle cx="20" cy="20" r="14" fill="#EEEFF5"/>
  <circle cx="20" cy="20" r="7.4" fill="#6D5CE7"/>
  <circle cx="20" cy="20" r="3.3" fill="#0B0D14"/>
  <circle cx="17.4" cy="17.2" r="1.5" fill="#fff"/>
</svg>`;

function showBusy(label = 'Reading…') {
  render(`<div class="row">${eyeSvg}<span class="busy">${esc(label)}</span></div>`);
}

function showError(message) {
  const p = render(`<div class="row">${eyeSvg}<span class="err">${esc(message)}</span>
    <button class="x" title="Close">✕</button></div>`);
  p.querySelector('.x').onclick = close;
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* ---------- result panel ---------- */

async function showResult(text) {
  lastText = text;
  if (!text) return showError('No text found in that.');

  const p = render(`
    <div class="row head">
      ${eyeSvg}<b>CopyEye</b><span class="grow"></span>
      <button class="x" title="Close">✕</button>
    </div>
    <textarea class="out" spellcheck="false"></textarea>
    <div class="row actions">
      <button class="primary" data-a="copy">Copy</button>
      <button data-a="translate">Translate</button>
      <span class="note"></span>
    </div>`);

  p.querySelector('.out').value = text;
  p.querySelector('.x').onclick = close;

  const note = p.querySelector('.note');
  p.querySelector('[data-a="copy"]').onclick = async () => {
    await navigator.clipboard.writeText(p.querySelector('.out').value);
    note.textContent = 'Copied';
    setTimeout(() => (note.textContent = ''), 1600);
  };

  p.querySelector('[data-a="translate"]').onclick = async () => {
    const btn = p.querySelector('[data-a="translate"]');
    btn.disabled = true;
    note.textContent = 'Translating…';
    try {
      const out = await translate(p.querySelector('.out').value);
      p.querySelector('.out').value = out;
      note.textContent = 'Translated';
    } catch (e) {
      note.textContent = String(e.message || e);
    } finally {
      btn.disabled = false;
    }
  };
}

/**
 * Chrome's built-in on-device translator. No key, no server, no cost — and it keeps the same
 * promise the rest of this extension makes. It is not on every Chrome yet, so the failure is
 * explained rather than swallowed.
 */
async function translate(text) {
  const api = self.Translator || self.translation;
  if (!api) throw new Error('This Chrome has no built-in translator yet.');

  const looksHindi = /[ऀ-ॿ]/.test(text);
  const pair = looksHindi
    ? { sourceLanguage: 'hi', targetLanguage: 'en' }
    : { sourceLanguage: 'en', targetLanguage: 'hi' };

  if (api.availability) {
    const state = await api.availability(pair);
    if (state === 'unavailable') throw new Error('That language pair is not available here.');
  }
  const translator = await (api.create ? api.create(pair) : api.createTranslator(pair));
  return await translator.translate(text);
}

/* ---------- video frame ---------- */

function grabVideoFrame() {
  const videos = [...document.querySelectorAll('video')]
    .filter((v) => v.videoWidth > 0)
    .sort((a, b) => b.videoWidth * b.videoHeight - a.videoWidth * a.videoHeight);
  const v = videos[0];
  if (!v) throw new Error('No playing video found here.');

  const c = document.createElement('canvas');
  c.width = v.videoWidth;
  c.height = v.videoHeight;
  c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
  try {
    return c.toDataURL('image/png');
  } catch {
    // A DRM or cross-origin video taints the canvas. Say so plainly — this is the one case the
    // extension genuinely cannot do, and pretending otherwise wastes the user's time.
    throw new Error('This video is protected, so its frames cannot be read.');
  }
}

/* ---------- drag a box over the page ---------- */

function pickRegion() {
  close();
  const veil = document.createElement('div');
  veil.style.cssText =
    'position:fixed;inset:0;z-index:2147483646;cursor:crosshair;background:rgba(11,13,20,.35)';
  const box = document.createElement('div');
  box.style.cssText =
    'position:fixed;border:2px solid #6D5CE7;background:rgba(109,92,231,.12);pointer-events:none;display:none';
  document.documentElement.append(veil, box);

  let sx = 0, sy = 0, drawing = false;
  const done = () => { veil.remove(); box.remove(); };

  veil.addEventListener('mousedown', (e) => {
    drawing = true; sx = e.clientX; sy = e.clientY;
    Object.assign(box.style, { display: 'block', left: sx + 'px', top: sy + 'px', width: '0', height: '0' });
  });
  veil.addEventListener('mousemove', (e) => {
    if (!drawing) return;
    Object.assign(box.style, {
      left: Math.min(sx, e.clientX) + 'px',
      top: Math.min(sy, e.clientY) + 'px',
      width: Math.abs(e.clientX - sx) + 'px',
      height: Math.abs(e.clientY - sy) + 'px',
    });
  });
  veil.addEventListener('mouseup', async (e) => {
    drawing = false;
    const rect = {
      x: Math.min(sx, e.clientX), y: Math.min(sy, e.clientY),
      w: Math.abs(e.clientX - sx), h: Math.abs(e.clientY - sy),
    };
    done();
    if (rect.w < 8 || rect.h < 8) return;
    showBusy('Reading that box…');
    try {
      await recogniseAndShow(await cropViewport(rect));
    } catch (err) {
      showError(String(err.message || err));
    }
  });
  addEventListener('keydown', function esc(e) {
    if (e.key === 'Escape') { done(); removeEventListener('keydown', esc); }
  });
}

/**
 * Crops the visible page to the drawn box.
 *
 * getDisplayMedia is used rather than any drawing trick because a web page cannot screenshot
 * itself — a content script can only read the DOM, and the DOM is not what the user is looking
 * at once video, canvas and cross-origin frames are involved. Chrome asks for consent, which is
 * the honest cost of reading pixels the page does not own.
 */
async function cropViewport(rect) {
  const stream = await navigator.mediaDevices.getDisplayMedia({
    video: { displaySurface: 'browser' },
    audio: false,
    preferCurrentTab: true,
  });
  try {
    const track = stream.getVideoTracks()[0];
    const video = document.createElement('video');
    video.srcObject = stream;
    video.muted = true;
    await video.play();
    // One frame is enough, but the first is often still black.
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));

    const scale = video.videoWidth / innerWidth;
    const c = document.createElement('canvas');
    c.width = Math.round(rect.w * scale);
    c.height = Math.round(rect.h * scale);
    c.getContext('2d').drawImage(
      video,
      Math.round(rect.x * scale), Math.round(rect.y * scale),
      c.width, c.height, 0, 0, c.width, c.height,
    );
    track.stop();
    return c.toDataURL('image/png');
  } finally {
    stream.getTracks().forEach((t) => t.stop());
  }
}

async function recogniseAndShow(dataUrl) {
  const res = await chrome.runtime.sendMessage({ type: 'copyeye:recognise', dataUrl });
  if (!res?.ok) throw new Error(res?.message || 'recognition failed');
  await showResult(res.text);
}

/* ---------- messages from the service worker ---------- */

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'copyeye:busy') showBusy();
  else if (msg?.type === 'copyeye:result') showResult(msg.text);
  else if (msg?.type === 'copyeye:error') showError(msg.message);
  else if (msg?.type === 'copyeye:pick-region') pickRegion();
  else if (msg?.type === 'copyeye:grab-video-frame') {
    showBusy('Reading this frame…');
    try {
      recogniseAndShow(grabVideoFrame()).catch((e) => showError(String(e.message || e)));
    } catch (e) {
      showError(String(e.message || e));
    }
  }
});

const PANEL_CSS = `
:host { all: initial }
.panel {
  font: 14px/1.45 ui-sans-serif, system-ui, -apple-system, sans-serif;
  width: 360px; max-width: calc(100vw - 32px);
  background: #FFF; color: #14151D;
  border: 1px solid rgba(20,21,29,.12); border-radius: 16px;
  box-shadow: 0 18px 48px rgba(11,13,20,.24);
  padding: 12px; display: grid; gap: 10px;
}
@media (prefers-color-scheme: dark) {
  .panel { background: #14161F; color: #ECEDF3; border-color: rgba(236,237,243,.14) }
  .out { background: #0E1017 !important; color: #ECEDF3 !important;
         border-color: rgba(236,237,243,.14) !important }
}
.row { display: flex; align-items: center; gap: 8px }
.grow { flex: 1 }
.eye { width: 22px; height: 22px; flex: none }
.head b { font-weight: 700; letter-spacing: -.01em }
.busy { opacity: .75 }
.err { color: #C0392B }
.out {
  width: 100%; min-height: 116px; max-height: 40vh; resize: vertical;
  font: 13px/1.5 ui-monospace, SFMono-Regular, Menlo, monospace;
  padding: 10px; border-radius: 10px; border: 1px solid rgba(20,21,29,.14);
  background: #F7F7FA; color: inherit; outline: none;
}
button {
  font: inherit; font-weight: 600; font-size: 13px; cursor: pointer;
  border: 1px solid rgba(20,21,29,.14); background: transparent; color: inherit;
  border-radius: 999px; padding: 7px 14px;
}
button:disabled { opacity: .5; cursor: default }
button.primary { background: #6D5CE7; border-color: #6D5CE7; color: #fff }
button.x { border: 0; padding: 4px 6px; opacity: .55; font-size: 15px }
.note { font-size: 12px; opacity: .7 }
`;
