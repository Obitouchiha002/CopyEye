/**
 * Service worker: owns the context menu, fetches the picture's bytes, and hands them to the
 * offscreen document that does the recognising.
 *
 * Why the bytes are fetched here rather than in the page: drawing a cross-origin image to a
 * canvas taints it, and `toDataURL` then throws. The extension has host permissions, so it can
 * simply ask for the file and read it cleanly. Video is the exception — a frame only exists in
 * the page, so the content script grabs that one itself.
 */

const MENU_IMAGE = 'copyeye-image';
const MENU_VIDEO = 'copyeye-video';
const MENU_REGION = 'copyeye-region';

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_IMAGE,
      title: 'Copy text from this image',
      contexts: ['image'],
    });
    chrome.contextMenus.create({
      id: MENU_VIDEO,
      title: 'Copy text from this frame',
      contexts: ['video'],
    });
    chrome.contextMenus.create({
      id: MENU_REGION,
      title: 'Copy text from a part of this page…',
      contexts: ['page', 'selection', 'link', 'image', 'video'],
    });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return;

  if (info.menuItemId === MENU_REGION) {
    send(tab.id, { type: 'copyeye:pick-region' }, info.frameId);
    return;
  }

  if (info.menuItemId === MENU_VIDEO) {
    // Only the page holds a decoded frame, so ask it for one.
    send(tab.id, { type: 'copyeye:grab-video-frame' }, info.frameId);
    return;
  }

  if (info.menuItemId === MENU_IMAGE && info.srcUrl) {
    send(tab.id, { type: 'copyeye:busy' }, info.frameId);
    try {
      const dataUrl = await fetchAsDataUrl(info.srcUrl);
      const text = await recognise(dataUrl);
      send(tab.id, { type: 'copyeye:result', text }, info.frameId);
    } catch (e) {
      send(tab.id, { type: 'copyeye:error', message: describe(e) }, info.frameId);
    }
  }
});

// The content script sends frames and cropped regions back here to be read.
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg?.type !== 'copyeye:recognise') return;
  recognise(msg.dataUrl)
    .then((text) => reply({ ok: true, text }))
    .catch((e) => reply({ ok: false, message: describe(e) }));
  return true; // keep the channel open for the async reply
});

function send(tabId, message, frameId) {
  const options = typeof frameId === 'number' ? { frameId } : undefined;
  chrome.tabs.sendMessage(tabId, message, options).catch(() => {});
}

function describe(e) {
  const m = String(e?.message || e || 'Something went wrong');
  if (/fetch|network|Failed to fetch/i.test(m)) return 'Could not read that image from the page.';
  return m;
}

async function fetchAsDataUrl(url) {
  if (url.startsWith('data:')) return url;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`image responded ${res.status}`);
  const blob = await res.blob();
  return await new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(fr.result);
    fr.onerror = () => reject(new Error('could not decode that image'));
    fr.readAsDataURL(blob);
  });
}

/* ---------- the offscreen document, which is where Tesseract actually runs ---------- */

let offscreenReady = null;

async function ensureOffscreen() {
  if (offscreenReady) return offscreenReady;
  offscreenReady = (async () => {
    const existing = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (existing.length) return;
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      // Tesseract needs a DOM: it decodes the image and runs its wasm worker there. A service
      // worker has neither a document nor a stable lifetime, so this is the supported home for it.
      reasons: ['DOM_SCRAPING'],
      justification: 'Runs the bundled OCR engine, which needs a document and a worker.',
    });
  })();
  return offscreenReady;
}

async function recognise(dataUrl) {
  await ensureOffscreen();
  const res = await chrome.runtime.sendMessage({ type: 'copyeye:offscreen-ocr', dataUrl });
  if (!res?.ok) throw new Error(res?.message || 'recognition failed');
  return res.text;
}
