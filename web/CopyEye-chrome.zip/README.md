# CopyEye for Chrome

Right-click an image, a video frame, or a box you draw on the page, and get the text out of it.
English and Hindi. Nothing leaves the machine.

## Loading it

`--load-extension` is blocked in Google Chrome, so this has to go in by hand:

1. `chrome://extensions`
2. Turn on **Developer mode** (top right)
3. **Load unpacked** → pick this folder

## What it does

| Where you right-click | What happens |
| --- | --- |
| An image | Its bytes are fetched by the extension and read |
| A video | The current frame is drawn to a canvas and read |
| Anywhere on the page | You drag a box, and just that box is read |

Then: **Copy**, or **Translate** (Hindi ⇄ English, picked from what the text looks like).

## Why the box option asks permission and the others don't

An image or a video frame is something the page already has, so the extension can read it
directly. A box drawn over the page is not — a web page cannot screenshot itself, and once
video, canvas and cross-origin frames are on screen the DOM is no longer what you are looking
at. So that one path uses `getDisplayMedia`, and Chrome asks. That prompt is the honest cost of
reading pixels the page does not own.

## Offline, and why that is a fact rather than a promise

`vendor/` holds Tesseract's worker and its wasm cores. `lang/` holds the English and Hindi
models. Both are files in this extension. `ocr.js`, which is the only place recognition happens,
contains no network call at all — turn the network off and it still works.

Translation uses Chrome's own built-in on-device translator. No key, no server. It is not on
every Chrome build yet; where it is missing the button says so instead of failing quietly.

## Known limits

- A DRM-protected video taints its canvas and cannot be read. The panel says so rather than
  returning empty text.
- Tesseract read clean rendered Hindi correctly in testing (`यह हिंदी टेक्स्ट है`, 1.0s in a real
  browser). Text inside compressed video will be harder than that — this engine is good, not the
  equal of the Android app's ML Kit models.
- First recognition after a browser restart pays for loading the wasm core.

## Development

`npm i` only pulls in what is needed to refresh `vendor/`. The extension itself has no build
step and no runtime dependency — what is in this folder is what runs.

To update the engine:

```sh
npm i tesseract.js@latest
CORE=$(find node_modules -type d -name tesseract.js-core | head -1)
cp node_modules/tesseract.js/dist/tesseract.min.js node_modules/tesseract.js/dist/worker.min.js vendor/
cp "$CORE"/*.wasm.js vendor/
```

The core and `tesseract.js` must be the matching major version — a mismatch fails at runtime
with `importScripts` not finding a core variant that the newer build expects.
